# ZeroTier Central Controller Docker Image

Dockerfile & startup script for use with [ZeroTier Central](https://my.zerotier.com).  Not intended for public use.
